// backend/signup.js
require('dotenv').config();

const express      = require('express');
const mongoose     = require('mongoose');
const helmet       = require('helmet');
const rateLimit    = require('express-rate-limit');
const cors         = require('cors');
const { body, validationResult } = require('express-validator');
const bcrypt       = require('bcrypt');
const User         = require('./models/User');

const app = express();

// --- MIDDLEWARES ---
app.use(helmet());
app.use(cors()); // adjust to your frontend URL
app.use(express.json());

// rate limiter
const limiter = rateLimit({
  windowMs:  +process.env.RATE_LIMIT_WINDOW_MS,
  max:       +process.env.RATE_LIMIT_MAX,
  message:   'Too many signup attempts, please try again later.'
});
app.use('/api/signup', limiter);

// --- CONNECT TO DB ---
mongoose.connect('mongodb://localhost:27017/yogaDB', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log("✅ MongoDB connected successfully"))
.catch(err => console.error("❌ MongoDB connection error:", err));


// --- SIGNUP ROUTE ---
app.post('/api/signup',
  // validate inputs
  body('name').trim().notEmpty().withMessage('Name required'),
  body('email').isEmail().withMessage('Valid email required'),
  body('password').isLength({ min: 6 }).withMessage('Password ≥ 6 chars'),
  body('confirmPassword').custom((val, { req }) => val === req.body.password)
    .withMessage('Passwords do not match'),
  body('age').isInt({ min: 1 }).withMessage('Valid age required'),
  body('height').isFloat({ min: 1 }).withMessage('Valid height required'),
  body('weight').isFloat({ min: 1 }).withMessage('Valid weight required'),
  body('bloodGroup').matches(/^(A|B|AB|O)[+-]$/).withMessage('Valid blood group'),

  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      // send first error message
      return res.status(400).json({ message: errors.array()[0].msg });
    }

    const { name, email, password, age, height, weight, bloodGroup } = req.body;

    try {
      // check if email exists
      if (await User.exists({ email })) {
        return res.status(409).json({ message: 'Email already registered.' });
      }

      // hash password
      const hashed = await bcrypt.hash(password, 12);

      const newUser = new User({
        name, email,
        password: hashed,
        age, height, weight,
        bloodGroup
      });
      await newUser.save();

      res.status(201).json({ message: 'User registered successfully!' });
    } catch (err) {
      console.error('Signup error:', err);
      res.status(500).json({ message: 'Server error, please try again.' });
    }
  }
);

// --- START SERVER ---
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
