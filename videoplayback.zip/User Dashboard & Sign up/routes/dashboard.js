const express = require("express");
const router = express.Router();
const DashboardData = require("../models/DashboardData");

router.post("/dashboard/save", async (req, res) => {
  const { userId, personalDetails, healthMetrics, dailyStreak, completedSessions, plans } = req.body;

  try {
    const existing = await DashboardData.findOne({ userId });
    if (existing) {
      await DashboardData.updateOne({ userId }, {
        $set: { personalDetails, healthMetrics, dailyStreak, completedSessions, plans },
      });
      return res.json({ message: "Dashboard updated" });
    }

    const dashboardData = new DashboardData({
      userId, personalDetails, healthMetrics, dailyStreak, completedSessions, plans
    });
    await dashboardData.save();
    res.json({ message: "Dashboard data saved" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});

router.get("/dashboard/:userId", async (req, res) => {
  try {
    const data = await DashboardData.findOne({ userId: req.params.userId });
    res.json(data);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});

module.exports = router;