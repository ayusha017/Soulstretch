const express = require("express");
const router = express.Router();
const User = require("../models/User");
const bcrypt = require("bcryptjs");
const { sendOTP } = require("../utils/mailer");

const otps = {}; // Temporary in-memory store

router.post("/forgot-password", async (req, res) => {
  const { email } = req.body;
  const user = await User.findOne({ email });
  if (!user) return res.status(400).json({ message: "User not found" });

  const otp = Math.floor(100000 + Math.random() * 900000).toString();
  otps[email] = otp;
  await sendOTP(email, otp);
  res.status(200).json({ message: "OTP sent to your email" });
});

router.post("/verify-otp", (req, res) => {
  const { email, otp } = req.body;
  if (otps[email] === otp) {
    return res.status(200).json({ message: "OTP verified" });
  } else {
    return res.status(400).json({ message: "Invalid OTP" });
  }
});

router.post("/reset-password", async (req, res) => {
  const { email, newPassword } = req.body;
  const hashedPassword = await bcrypt.hash(newPassword, 10);
  await User.findOneAndUpdate({ email }, { password: hashedPassword });
  delete otps[email];
  res.status(200).json({ message: "Password reset successful" });
});

module.exports = router;