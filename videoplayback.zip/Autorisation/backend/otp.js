const otpStore = new Map(); // key: email, value: { otp, expiresAt }

module.exports = otpStore;
