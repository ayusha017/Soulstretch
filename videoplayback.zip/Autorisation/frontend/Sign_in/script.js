const loginForm = document.getElementById("loginForm");
const errorMsg = document.getElementById("errorMsg");

loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
try {
    const res = await fetch("http://localhost:3000/api/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
  
    // Check if the response is JSON
    const contentType = res.headers.get("content-type");
    if (res.ok && contentType && contentType.includes("application/json")) {
      const data = await res.json();
      alert("Login successful!");
      window.location.href = "../../../Home/Home.html";
    } else {
      const text = await res.text(); // get the raw HTML or error text
      document.getElementById("errorMsg").textContent =
        "Login failed: " + text;
    }
  } catch (error) {
    document.getElementById("errorMsg").textContent = "Network error. Try again.";
    console.error("Fetch error:", error);
  }
});